define( [], function () {
    'use strict';
  
     

    //----------individual accordion labels-------------
    //Dimensions
  /*  var objLabel = {
        ref: "props.objLabel",
        label: "Object Label",
        type: "string",
        expression: "optional"
    };

    var objType = {
        ref : "props.objType",
        label : "Object Type",
        type : "string",
        defaultValue : false
    };
    var objID = {
        ref : "props.objID",
        label : "object ID",
        type : "string",
        
    };
	var sortOrder = {
		ref : "props.sortOrder",
		label: "sort",
		type: "number"
	}
   */
     

    var objType = {
        ref : "qDef.objType",
        label : "Object Type",
        type : "string",
        defaultValue : "popup"
    };
    var objID = {
        ref : "qDef.objID",
        label : "object ID",
        type : "string",
        
    };
	
	
	
	var objStyle = {
        ref: "qDef.objStyle",
        label: "Object Style",
        type: "string",
		defaultValue: "display",
        expression: "optional"
    };
	
	var objStyleValue = {
        ref: "qDef.objStyleValue",
        label: "Object objStyle Value",
        type: "string",
		defaultValue: "if(vHidePopup=0,'block','none')",
        expression: "optional"
    };
	
	var Left = {
		ref: "qDef.Left",
        label: "change offset location by left",
        type: "number",
		defaultValue: 700,
        expression: "optional"
	};
	
	var top = {
		ref: "qDef.top",
        label: "change offset location by top",
        type: "number",
		defaultValue: 400,
        expression: "optional"
	};
	
	var width = {
		ref: "qDef.width",
        label: "width",
        type: "string",
		defaultValue:"init",
		expression: "optional"
	};
	
	var height = {
		ref: "qDef.height",
        label: "height",
        type: "string",
		defaultValue:"init",
		expression: "optional"
	};
	
	
	var modal = {
		label:"modal",
		type: "boolean",
		component: "switch",
		label: "רקע",
		ref: "qDef.modal",
		options: [{
			value: true,
			label: "רקע מושחר"
		}, {
			value: false,
			label: "ללא רקע"
		}],
		defaultValue: false
	}
	
	
	
	
//qHyperCube.qDimensionInfo
    //----------final properties creation---------------
    return {
        type: "items",
        component: "accordion",
        items: {
           
            appearance: {
               // uses: "settings"
                uses: "measures"
				,items: {
						// component: "expandable-items",
                        header1: {
							
                            type: "items",
                            label: "Objects1",
                            items: {
                               
                                objectType :     objType,
                                objectID:               objID,
								objectStyle:         objStyle,
								objStyleValue: objStyleValue,
								Left: Left,
								top:top,
								width:width,
								height:height
								
								
								
                            }
                        }
						
                        
                    }
            }
			,global: {
				component: "accordion",
				
				label: "global",
				items:{
					modal: modal
					
				}
				
			}	
        }
    };

} );
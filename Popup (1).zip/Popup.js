// location.href="http://127.0.0.1:54187/qvfremote/extensions/hubtest4/hubtest4.html"+'?appid=41cc32a4-b793-49d0-aa39-568d6e158891';
var changeCssResize='0';
var pageName = window.location.pathname;
var gridZoom = $(".qv-gridzoom").length;
var appObjectList={},objectList=0,MasterobjectList=0;
var appMasterObjectList={},masterObjectList={},appMasterObjectListFiltered={},appMasterDimensionsList={};
var FilterappMasterObjectList = 
	[{
		"filterSize" :1,
		"objectID" :1
	}];
								
var indKey=0,indKeyObj=0,autoSort=0;
var mapID='';
var insrtAfter='',objectId='';
var tidString='',objectIDString='',mobileLeftClick=0,waitS=100;;
 
var counter=0;
define( [ "qlik", "jquery","./properties",'css!./popup'],


function ( qlik,layout7,props) {
	//confirm(location.href);
	
	
	
	
	
	
	return {
		definition: props,
            initialProperties: {
                    qHyperCubeDef: {
                      qDimensions: [],
                      qMeasures: [],
                      qInitialDataFetch: [
                          {
                              qWidth: 10,
                              qHeight: 100
                          }
                      ]
                    }
            },
		support : {
			snapshot: false,
			export: function( layout ) {
				return layout.props.exportenabled;
			},
			exportData : false
		},
		
		paint: function ($element,layout) {
			
			/*	$($('.qv-gridcell[tid="yHukhT"]').find('input')).on('input',function(event){
					var SearchInput =  this.value;
					var fldArr =[];
					$.each(appMasterDimensionsList,function(index,val){
						fldArr.push(val.dimValue);
					});
					var fld = fldArr;
					googleSearch(SearchInput,fld);
				});	
		  */
			 //flags to prevent infinite loop
			 this.painted = true;
			 var pageNamePrev = pageName;
			 pageName = location.pathname;
			 var gridZoomPrev = gridZoom;
			 	gridZoom = $(".qv-gridzoom").length;
				//alert(pageName);
						 
						  //|| window.height()<640
			if($(window).width() < 640 || $(window).height()<600 ){
				
			}
			//desktop/*******************************************************
			else{
				
				var changeCssResizePrev = changeCssResize;
				changeCssResize='tablet';
				
				//qlik.resize();
				if(changeCssResizePrev == changeCssResize && this.painted == true  && pageNamePrev ==  pageName ){
					var a=1;
					//return counter=0;
				}
				//show whats hidden in mobile back
				var isModal = layout.qDef.modal;
				
				if(isModal && $('.modal').length==0){
							var modal = $("<div>",{
								'class': "modal",
								'id': "modal1"
							}).appendTo('#grid-wrap');
							
						};
				for(i=0; i<layout.qHyperCube.qMeasureInfo.length; i++){
					var objId = layout.qHyperCube.qMeasureInfo[i].objID;
					var objStyle = layout.qHyperCube.qMeasureInfo[i].objStyle;
					var objStyleValue = layout.qHyperCube.qMeasureInfo[i].objStyleValue;
					var objType = layout.qHyperCube.qMeasureInfo[i].objType;
					var objTitle = layout.qHyperCube.qMeasureInfo[i].qFallbackTitle;
					var objLeft = layout.qHyperCube.qMeasureInfo[i].Left;
					var objTop = layout.qHyperCube.qMeasureInfo[i].top;
					var objWidth = layout.qHyperCube.qMeasureInfo[i].width;
					var objHeight = layout.qHyperCube.qMeasureInfo[i].height;
					
					if($('.qv-gridcell[tid=' + objId + ']').length==0){
						var oldObjID = objId;
						var currSheetName = $('span.qs-sheet-toolbar-sheet-title').text();
						try{
							objId = _.findWhere(appObjectList,{masterId:oldObjID,sheetTitle:currSheetName}).objectID;
						}
						catch(e){
							if(window.location.pathname.search('edit')==-1){
								console.log("objectid "+ objId + " not exists on: '" + objTitle + "'");
							}
							else{
								alert("objectid "+ objId + " not exists on: '" + objTitle + "'" + "on extension popup" );
							}
							
						}
					}
					
					//check if not mobile and hides it
					//if(desktop==true && objStyleValue!='block'){$('.qv-gridcell[tid=' + objId + ']').css("display","flex");}
						
						if(window.location.pathname.search('edit')==-1){
							
							showHide();
							var cnt=0;
							
							//$('a.ng-scope.ng-isolate-scope.lui-icon.lui-icon--expand.white.border').toggle()//option to disable zoom
						}
						
					
					
					
						//$('.qv-gridcell[tid=' + objId + ']').toggle(950);

					//filter hide and show
					
				}
				
				var parent = $element.closest('.qv-gridcell');
				$(parent).css("display","block");
				//qlik.resize();
				
				
			}
			
				
			//add your rendering code here
			

			function showHide(){
				if(objStyleValue=='block' ){

					//$('.qv-gridcell[tid=' + objId + ']').css(objStyle,objStyleValue).slideToggle("950")
					if(objType=='popup'){
						var initLeft = $('.qv-gridcell[tid=' + objId + ']').offset().left;
						var initTop = $('.qv-gridcell[tid=' + objId + ']').offset().top;
						
						$('.qv-gridcell[tid=' + objId + ']').show('slow',callbacks).addClass('popup').offset({top:objTop,left:objLeft}).css(
						{
							'width':objWidth,
							'heigth':objHeight
						});
					}
					
					
					
					//qlik.resize();
				} 
				else{
					$('.qv-gridcell[tid=' + objId + ']').css(objStyle,objStyleValue);
					$('#modal1').hide();
					//$(modal).hide();
				}
			}
			function callbacks(){
						//$('.qv-gridcell[tid=' + objId + ']').css(objStyle,objStyleValue);
						//var filterCollapse = $('.qv-gridcell[tid=' + objId + ']').find('.qv-filterpane-collapsed');
						$('.popup').css({
							'width':objWidth,
							'height':objHeight
							
						});
						//qlik.resize();
						$('#modal1').show();
						var nav = $('.qv-gridcell[tid=' + objId + ']').find('.qv-object-nav');
						if($(".removeModal").length<1){
							var close = $("<a>",{
								'class': "lui-icon lui-icon--remove big removeModal",
								'title': "close"
							}).appendTo(nav);
							$(close).click(function(){
								$('#modal1').hide();
								$('.qv-gridcell[tid=' + objId + ']').hide();
								qlik.currApp().variable.setStringValue('vHidePopup','=1');
								
							});
						}
						
						
						
					}
			//$element.html( "" );
			//needed for export
			
			//$($element).css("display","none");
		
			 return qlik.Promise.resolve();
				 
				
				 
			
			
		}
	};

} 
	
);

